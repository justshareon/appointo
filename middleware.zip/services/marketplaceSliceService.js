/**
 * Lazy offer slices — MySQL + in-memory cache per scope/category/type.
 * Only fetches requested sources (deals | vendors | products).
 */
const dealsService = require('../dealsService');
const db = require('../database');
const productService = require('./productService');

const { clampLimit, sortTodayRecentFirst, withinRecentDays } = require('../utils/recentSlice');

const sliceMem = new Map();
const SLICE_TTL_MS = 5 * 60 * 1000;
const norm = (v) => String(v || '').trim().toLowerCase();

function sliceKey({ scope, category, type, sources, city, locality }) {
  return `${scope}|${category}|${type}|${sources}|${city}|${locality}`;
}

function inferCategory(raw) {
  const s = norm(raw);
  const map = [
    ['food', ['food', 'restaurant', 'cafe', 'pizza']],
    ['grocery', ['grocery', 'supermarket', 'mart']],
    ['fashion', ['fashion', 'apparel', 'clothing']],
    ['electronics', ['electronic', 'mobile', 'laptop']],
    ['travel', ['travel', 'flight', 'holiday']],
    ['health', ['health', 'hospital', 'clinic']],
    ['salon', ['salon', 'spa', 'hair']],
    ['home', ['home', 'furniture', 'decor']],
    ['beauty', ['beauty', 'cosmetic', 'makeup']],
    ['kids', ['kid', 'toy', 'baby']],
    ['sports', ['sport', 'fitness', 'gym']],
    ['hotel', ['hotel', 'stay', 'resort']],
    ['pharmacy', ['pharma', 'medicine', 'chemist']],
    ['auto', ['auto', 'car', 'bike']],
  ];
  for (const [key, needles] of map) {
    if (needles.some((n) => s.includes(n))) return key;
  }
  return 'food';
}

function inferType(text) {
  const blob = String(text || '');
  if (/flash|lightning/i.test(blob)) return 'flash';
  if (/bogo|buy\s*1/i.test(blob)) return 'bogo';
  if (/cashback/i.test(blob)) return 'cashback';
  if (/festival|diwali|holi/i.test(blob)) return 'festival';
  if (/daily deal|deal of the day/i.test(blob)) return 'daily';
  if (/bank|upi|card offer/i.test(blob)) return 'bank';
  if (/combo|bundle/i.test(blob)) return 'combo';
  if (/new user|first order/i.test(blob)) return 'new_user';
  if (/flat\s+\d|₹\s*\d+/i.test(blob)) return 'flat';
  if (/\d+\s*%/.test(blob)) return 'percent';
  return 'percent';
}

function matchesScope(row, scope, ctx) {
  if (!scope || scope === 'All') return true;
  const city = norm(ctx.city);
  const locality = norm(ctx.locality || ctx.town);
  const loc = norm(row.location_name || row.city || row.location || '');
  if (scope === 'local' || scope === 'town') {
    return !city || loc.includes(city) || loc.includes(locality);
  }
  if (scope === 'city') return !city || loc.includes(city);
  if (scope === 'national') return norm(row.country || 'in') === 'in' || !row.country;
  return true;
}

function filterRows(rows, { category, type, scope, ctx }) {
  let list = Array.isArray(rows) ? rows : [];
  if (category && category !== 'all') {
    list = list.filter((r) => inferCategory(r.category || r.shop_name || r.name || r.title) === category);
  }
  if (type && type !== 'all') {
    list = list.filter((r) => {
      const blob = `${r.offer || ''} ${r.current_offer || ''} ${r.discount_text_raw || ''} ${r.title || ''}`;
      return inferType(blob) === type;
    });
  }
  if (scope && scope !== 'All') {
    list = list.filter((r) => matchesScope(r, scope, ctx));
  }
  return list;
}

async function fetchDeals(limit) {
  try {
    // Layered: MySQL deals when synced, in-memory vendor products until then.
    const rows = await dealsService.getDealsFromDB({ limit: Math.min(Math.max(limit, 20), 40) });
    return Array.isArray(rows) ? rows : [];
  } catch (_) {
    return [];
  }
}

async function fetchVendors() {
  try {
    const rows = await db.getVendors(true, 1, 40, 'newest', '', true, 'offer');
    return (rows || []).filter(
      (v) => v.features_offer === true || v.features_offer === 1 || v.features_offer === '1'
    );
  } catch (_) {
    return [];
  }
}

async function fetchProducts(limit) {
  try {
    const rows = await productService.getAllProducts();
    const list = Array.isArray(rows) ? rows : [];
    return list.filter((p) => p.offer && !/^no offer$/i.test(String(p.offer))).slice(0, Math.min(Math.max(limit, 20), 40));
  } catch (_) {
    return [];
  }
}

async function getSlice(opts = {}) {
  const safeLimit = clampLimit(opts.limit, { def: 20, max: 30 });
  const {
    scope = 'All',
    category = 'all',
    type = 'all',
    sources = 'deals',
    city = '',
    locality = '',
  } = opts;
  const ctx = { city, locality };
  const key = sliceKey({ scope, category, type, sources, city, locality });
  const hit = sliceMem.get(key);
  if (hit && Date.now() - hit.ts < SLICE_TTL_MS) {
    return { ...hit.data, cached: true };
  }

  const srcList = String(sources || 'deals')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const result = { vendors: [], products: [], deals: [], scope, category, type, sources: srcList };

  if (srcList.includes('deals')) {
    result.deals = sortTodayRecentFirst(
      filterRows(await fetchDeals(safeLimit * 2), { category, type, scope, ctx }),
      safeLimit,
      ['updated_at', 'created_at', 'date']
    );
  }
  if (srcList.includes('vendors')) {
    result.vendors = filterRows(await fetchVendors(), { category, type, scope, ctx }).slice(0, safeLimit);
  }
  if (srcList.includes('products')) {
    result.products = filterRows(await fetchProducts(safeLimit * 2), { category, type, scope, ctx }).slice(0, safeLimit);
  }

  sliceMem.set(key, { data: result, ts: Date.now() });
  return { ...result, cached: false };
}

module.exports = { getSlice, sliceKey };
